var hd=document.getElementById('hd'),mn=document.getElementById('menu');
addEventListener('scroll',function(){hd.classList.toggle('sc',scrollY>20)});
document.getElementById('bg').onclick=function(){mn.classList.toggle('open')};
mn.onclick=function(){mn.classList.remove('open')};
var md=document.getElementById("md"),bk=document.getElementById("bk"),NL=String.fromCharCode(10);
function g(i){return document.getElementById(i)}
for(var h=8;h<18;h++){["00","30"].forEach(function(m){var l=h+"h"+(m==="00"?"":m);g("hh").add(new Option(l,l))})}
function openBk(pl){if(pl)g("pl").value=pl;var d=new Date();d.setMinutes(d.getMinutes()-d.getTimezoneOffset());g("dt").min=d.toISOString().slice(0,10);md.hidden=false;document.body.style.overflow="hidden";g("bn").focus()}
function closeBk(){md.hidden=true;document.body.style.overflow=""}
document.querySelectorAll("[data-book]").forEach(function(b){b.addEventListener("click",function(){openBk(b.getAttribute("data-book"))})});
g("mx").onclick=closeBk;md.addEventListener("click",function(e){if(e.target===md)closeBk()});
addEventListener("keydown",function(e){if(e.key==="Escape"&&!md.hidden)closeBk()});
bk.onsubmit=function(e){e.preventDefault();var d=new Date(g("dt").value+"T12:00:00");
if(d.getDay()===0||d.getDay()===6){g("er").textContent="Atendemos de segunda a sexta. Escolha outro dia.";return}
g("er").textContent="";
var t="Olá! Gostaria de agendar na JM Auto-Lavagens:"+NL+"• Nome: "+g("bn").value+NL+"• Veículo: "+g("vc").value+NL+"• Serviço: "+g("pl").value+NL+"• Data: "+d.toLocaleDateString("pt-BR")+" às "+g("hh").value+(g("ob").value?NL+"• Obs.: "+g("ob").value:"");
window.open("https://wa.me/5518996746497?text="+encodeURIComponent(t),"_blank","noopener,noreferrer");closeBk();bk.reset()};
var io=new IntersectionObserver(function(e){e.forEach(function(x){if(x.isIntersecting){x.target.classList.add('in');io.unobserve(x.target)}})},{threshold:.12});
document.querySelectorAll('.rv').forEach(function(el){io.observe(el)});
var fm=document.getElementById('fm');if(fm)fm.onsubmit=function(ev){ev.preventDefault();var t='Olá, sou '+document.getElementById('nm').value+'. '+document.getElementById('ms').value;window.open('https://wa.me/5518996746497?text='+encodeURIComponent(t),'_blank','noopener,noreferrer')};
